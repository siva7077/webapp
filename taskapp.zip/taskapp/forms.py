#taskapp/forms.py
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import get_user_model, authenticate
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User
from django_countries import countries
from django_countries.fields import CountryField
from django_countries.widgets import CountrySelectWidget

from taskapp.models import Child, TrustedPerson
from .models import CustomUser


class SignUpForm(UserCreationForm):
    email = forms.EmailField(max_length=254, help_text='Required. Enter a valid email address.')
    phone_number = forms.CharField(max_length=15, help_text='Required. Enter your phone number.',label='Phone Number')

    class Meta:
        model = get_user_model()
        fields = ['username', 'email', 'phone_number', 'password1', 'password2']



class LoginForm(AuthenticationForm):
    class Meta:
        model = User

# taskapp/forms.py

from django import forms
from .models import Child

class AttendanceForm(forms.Form):
    date = forms.DateField(widget=forms.DateInput(attrs={'type': 'date'}))
    child = forms.ModelChoiceField(queryset=Child.objects.all())
    attended = forms.BooleanField(required=False)
    def __init__(self, user, *args, **kwargs):
        user = kwargs.pop('user', None)
        user_children = kwargs.pop('user_children', None)
        super(AttendanceForm, self).__init__(*args, **kwargs)

        if user_children:
            self.fields['child'].queryset = user_children
        self.user = user


# class ChildForm(forms.ModelForm):
#     GENDER_CHOICES = (
#         ('M', 'Male'),
#         ('F', 'Female'),
#         ('O', 'Prefer Not to disclose'),
#     )
#
#     gender = forms.ChoiceField(choices=GENDER_CHOICES, widget=forms.Select())
#     age=forms.CheckboxInput()
#     class Meta:
#         model = Child
#         fields = ['name', 'gender', 'dob','interests']
class TrustedPersonForm(forms.ModelForm):
    phone_country_code = forms.ChoiceField(choices=[('+' + code, f"{name} (+{code})") for code, name in countries],
                                           widget=forms.Select(attrs={'class': 'custom-select'}))

    class Meta:
        model = TrustedPerson
        fields = ['name', 'relation', 'phone_country_code', 'phone_number']

from django import forms
from django.contrib.auth.forms import UserChangeForm
from django.contrib.auth import get_user_model
from django.core.exceptions import ValidationError

class ProfileForm(UserChangeForm):
    current_password = forms.CharField(
        label='Current Password',
        widget=forms.PasswordInput,
        required=False,
    )
    new_password1 = forms.CharField(
        label='New Password',
        widget=forms.PasswordInput,
        required=False,
    )
    new_password2 = forms.CharField(
        label='Confirm New Password',
        widget=forms.PasswordInput,
        required=False,
    )

    class Meta:
        model = get_user_model()
        fields = ['username', 'email', 'phone_number']

    def clean_current_password(self):
        current_password = self.cleaned_data.get('current_password')
        if current_password and not self.user.check_password(current_password):
            raise ValidationError('Incorrect current password')
        return current_password

    def clean(self):
        cleaned_data = super().clean()
        new_password1 = cleaned_data.get('new_password1')
        new_password2 = cleaned_data.get('new_password2')

        if new_password1 and new_password2 and new_password1 != new_password2:
            raise ValidationError('New passwords do not match')

