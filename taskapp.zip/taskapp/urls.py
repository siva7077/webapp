# taskapp/urls.py

from django.urls import path

from . import views
from .views import home, signup, login_view, logout_view, add_child, header, calendar_view, save_event, \
    manage_children_view, add_trusted_person, view_events_by_child_and_date, submit_attendance, child_dashboard, \
    profile, event_calendar, get_events
from .views import EventListCreateView, EventRetrieveUpdateDestroyView
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('', home, name='home'),
    path('header/', header, name='header'),
    path('signup/', signup, name='signup'),
    path('login/', login_view, name='login'),
    path('logout/', logout_view, name='logout'),
    path('add_child/', add_child, name='add_child'),
    path('calendar/', calendar_view, name='calendar'),
    path('save_event/', save_event, name='save_event'),
    path('manage_children/', manage_children_view, name='manage_children'),
    path('add-trusted-person/', add_trusted_person, name='add_trusted_person'),
    path('api/events/', EventListCreateView.as_view(), name='event-list-create'),
    path('api/events/<int:pk>/', EventRetrieveUpdateDestroyView.as_view(), name='event-retrieve-update-destroy'),
    path('view_events_by_child_and_date/', view_events_by_child_and_date, name='view_events_by_child_and_date'),
    path('submit_attendance/', submit_attendance, name='submit_attendance'),
    path('child_dashboard/', child_dashboard, name='child_dashboard'),
    path('profile/', profile, name='profile'),
    path('password_reset/', auth_views.PasswordResetView.as_view(
        template_name='registration/password_reset_custom.html',
        email_template_name='registration/password_reset_email.html',
        subject_template_name='registration/password_reset_subject.txt'
    ), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(
        template_name='registration/password_reset_done.html'
    ), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(
        template_name='registration/password_reset_confirm.html'
    ), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(
        template_name='registration/password_reset_complete.html'
    ), name='password_reset_complete'),

    path('get_events/', get_events, name='get_events'),
    path('eventcalendar/', event_calendar, name='event_calendar'),
    path('get_child_color/', views.get_child_color, name='get_child_color'),



]



